// SignUpScreen.js

import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';

const SignUpScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignUp = async () => {
    try {
      const response = await axios.post('https://dev.iqrakitab.net/api/signup', {
        email,
        password
      });
      if (response.status === 200) {
        alert('Sign up successful! Please log in.');
        navigation.navigate('Login');
      } else {
        alert(response.data.message || 'Sign up failed');
      }
    } catch (error) {
      alert(error);
      console.log("error:",error);
    }
  };

  return (
    <View style={styles.container}>
      <Text>Sign Up</Text>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      <Button title="Sign Up" onPress={handleSignUp} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#333',
    padding: 10,
    marginVertical: 10,
    width: '50%',
    backgroundColor:'gray',
    opacity:0.65,

    borderTopLeftRadius:10,
    borderTopRightRadius:10,
    borderBottomLeftRadius:10,
    borderBottomRightRadius:10,
  },
  },
);

export default SignUpScreen;
